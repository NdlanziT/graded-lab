import React, { useContext } from 'react';
import { View, Text, Button, FlatList, Image, StyleSheet } from 'react-native';
import { CartContext } from '../contexts/CartContext'; 

const MenuScreen = ({ navigation }) => {
  const { addItemToCart, getTotalPrice } = useContext(CartContext); 

  const menuItems = [

    {
      id: '1',
      name: 'Bunny Chow',
      description: 'Hollowed-out loaf of bread filled with spicy curry.',
      price: 'R75.00',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRi6zGDe5kOjc5ntOL0xuwj_Av16RrIVhjf6g&s', 
    },
    {
      id: '2',
      name: 'Braai',
      description: 'Traditional South African barbecue with a variety of meats and sides.',
      price: 'R150.00',
      image: 'https://imgs.search.brave.com/9Jl6AG43IGw02JtmE3yT8GDZj8MqvduEE2QmQawM8z4/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5pc3RvY2twaG90/by5jb20vaWQvMTQx/MzM2ODU0NC9waG90/by9zb3V0aC1hZnJp/Y2FuLWJyYWFpLmpw/Zz9zPTYxMng2MTIm/dz0wJms9MjAmYz1Q/cmxWd0ZKd2k0bV96/TktzVlllYXoyZS1V/WHhCR0tQbEJWNzVj/SWdWWEJFPQ', 
    },
    {
      id: '3',
      name: 'Bobotie',
      description: 'Spiced minced meat baked with an egg-based topping.',
      price: 'R180.00',
      image: 'https://imgs.search.brave.com/cuQssDc7rAc76ZZmFSLx9cGC5v8bbJOQfp6tRIC8fHs/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly90YXN0/ZW9mdGhlcGxhY2Uu/Y29tL3dwLWNvbnRl/bnQvdXBsb2Fkcy8y/MDE3LzA1L0JvYm90/aWUtYXQtVGFzdGVP/ZlRoZVBsYWNlLmNv/bS1pbmxpbmUtMi0x/MDI0eDQxMi5qcGc', // 
    },
    {
      id: '4',
      name: 'Potjiekos',
      description: 'Slow-cooked stew made with meat, vegetables, and spices in a cast-iron pot.',
      price: 'R270.00',
      image: 'https://imgs.search.brave.com/JrJkevCLoZZ6zLD0tSErQefEJ_1u4nvF-r9TgW3Stko/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9jZG4u/YnJpZWZseS5jby56/YS9pbWFnZXMvMTEy/MC9mMDQwZmFmNGRh/NGU1MmVkLmpwZWc_/dj0x',
    },
    {
      id: '5',
      name: 'Vetkoek',
      description: 'Fried bread dough, often served with a savory filling or sweet toppings.',
      price: 'R65.00',
      image: 'https://imgs.search.brave.com/LYRTknHHA2ej6fo68pf09ZT-f0gNz5XYW35TRZT35Zw/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly93d3cu/YWZyaWNhbmJpdGVz/LmNvbS93cC1jb250/ZW50L3VwbG9hZHMv/MjAxNS8wMi9JTUdf/MzQ2MjEtMS01NDN4/NjUwLmpwZw', 
    },
    {
      id: '6',
      name: 'Sosaties',
      description: 'Skewered and grilled meat with a spicy marinade.',
      price: 'R80.00',
      image: 'https://imgs.search.brave.com/CZCTOQ4rmHm_GXRv0vEGOudpUHiNaoxGyq25gMZ4XQ8/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9pbWcu/YXBtY2RuLm9yZy9k/MjkzZmYxNmY0NmZh/NjIyZjU3YTNlMWE1/YTU3YTRlNDIwMzFj/Y2YwL3VuY3JvcHBl/ZC8wNmVhMjYtMjAy/MzA5MTItd25rLWxh/bWItc29zYXRpZXMt/ZnJvbS1zb3V0aC1v/Zm9tZXRoZXItMjAwMC5qcGc', 
    },
    {
      id: '8',
      name: 'Chakalaka',
      description: 'Spicy vegetable relish often served with bread or meat.',
      price: 'R25.00',
      image: 'https://imgs.search.brave.com/fKygyV_zMFTfkIJ1NtCkXwUkgfTp4QOConglSfuzHl8/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9iZWFz/dGx5ZWF0cy5jby56/YS93cC1jb250ZW50/L3VwbG9hZHMvMjAy/MS8wMy9DaGFrYWxh/a2EtNzUweDUwMC5q/cGVn', // Replace with actual image URL
    },
    {
      id: '9',
      name: 'R75',
      description: 'Traditional maize porridge served with grilled sausage.',
      price: 'R220.00',
      image: 'https://imgs.search.brave.com/zY9_dH_4uzvy4Tu6SorL38XWua4ZKo3zVgA__6nglCI/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly93d3cu/c2lkZWNoZWYuY29t/L3JlY2lwZS8zN2Q0/OGIyYy05NjRjLTQz/MGEtYjRhZS0xNmM4/ZjczNDZiZWIuanBn/P2Q9MTQwOHgxMTIw', 
    },
    
    {
      id: '10',
      name: 'Margherita Pizza',
      description: 'Classic pizza with tomatoes, mozzarella, and basil.',
      price: 'R186.00',
      image: 'https://imgs.search.brave.com/OCrausmluCNItjqghh8Q-WRTZxqq0P8lY15KyN1lziM/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9zdGF0/aWMwMS5ueXQuY29t/L2ltYWdlcy8yMDE0/LzA0LzA5L2Rpbmlu/Zy8wOUpQUElaWkEy/LzA5SlBQSVpaQTIt/bWVkaXVtVGhyZWVC/eVR3bzQ0MC5qcGc_/d2lkdGg9MTI4MCZx/dWFsaXR5PTc1JmF1/dG89d2VicA',
    },
    {
      id: '11',
      name: 'Pepperoni Pizza',
      description: 'Pizza topped with spicy pepperoni slices.',
      price: 'R210.00',
      image: 'https://imgs.search.brave.com/ePNY5rfS6qs_mVvQr9rsJRnNbcNII04NPWCWgsQ9jtk/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly93d3cu/c2ltcGx5cmVjaXBl/cy5jb20vdGhtYi9w/allNTGNzS0hrcjhE/OHRZaXhtYUZOeHBw/UHc9LzE1MDB4MC9m/aWx0ZXJzOm5vX3Vw/c2NhbGUoKTptYXhf/Ynl0ZXMoMTUwMDAw/KTpzdHJpcF9pY2Mo/KS9fX29wdF9fYWJv/dXRjb21fX2NvZXVz/X19yZXNvdXJjZXNf/X2NvbnRlbnRfbWln/cmF0aW9uX19zaW1w/bHlfcmVjaXBlc19f/dXBsb2Fkc19fMjAx/OV9fMDlfX2Vhc3kt/cGVwcGVyb25pLXBp/enphLWxlYWQtMy04/ZjI1Njc0NmQ2NDk0/MDRiYWEzNmE0NGQy/NzEzMjliYy5qcGc', 
    },
  ];

  const handleAddToCart = (item) => {
    addItemToCart(item); 
    navigation.navigate('Cart'); 
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={menuItems}
        renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <Text style={styles.name}>{item.name}</Text>
            <Text>{item.description}</Text>
            <Text>{item.price}</Text>
            <Button
              title="Add to Cart"
              onPress={() => handleAddToCart(item)}
            />
          </View>
        )}
        keyExtractor={(item) => item.id}
      />
      <View style={styles.totalContainer}>
        <Text style={styles.totalText}>Total Price: R{getTotalPrice().toFixed(2)}</Text>
      </View>
      <View style={styles.navigationContainer}>
        <Button
          title="Go to Cart"
          onPress={() => navigation.navigate('Cart')}
        />
        <Button
          title="Go to Profile"
          onPress={() => navigation.navigate('Profile')}
        />
        <Button
          title="Go to user details"
          onPress={() => navigation.navigate('Form1')}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  itemContainer: {
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    borderRadius: 5,
  },
  image: {
    width: '100%',
    height: 150,
    borderRadius: 5,
  },
  name: {
    fontWeight: 'bold',
    fontSize: 18,
  },
  totalContainer: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#f8f8f8',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  totalText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  navigationContainer: {
    marginTop: 20,
  },
});

export default MenuScreen;
