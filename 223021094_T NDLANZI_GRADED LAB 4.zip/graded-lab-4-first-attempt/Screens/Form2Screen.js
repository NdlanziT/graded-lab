import React, { useContext, useState } from 'react';
import { View, TextInput, Button, Text } from 'react-native';
import { FormContext } from '../contexts/FormContext';

const Form2Screen = ({ navigation }) => {
  const { userData, setUserData } = useContext(FormContext);
  const [address, setAddress] = useState(userData.address);
  const [city, setCity] = useState(userData.city);
  const [state, setState] = useState(userData.state);
  const [zip, setZip] = useState(userData.zip);

  const handleNext = () => {
    if (address && city && state && zip) {
      setUserData({ ...userData, address, city, state, zip });
      navigation.navigate('Form3');
    } else {
      alert('Please fill in all fields');
    }
  };

  return (
    <View>
      <Text>Address Details</Text>
      <TextInput
        placeholder="Address"
        value={address}
        onChangeText={setAddress}
      />
      <TextInput
        placeholder="City"
        value={city}
        onChangeText={setCity}
      />
      <TextInput
        placeholder="State"
        value={state}
        onChangeText={setState}
      />
      <TextInput
        placeholder="Zip Code"
        value={zip}
        onChangeText={setZip}
      />
      <Button title="Next" onPress={handleNext} />
    </View>
  );
};

export default Form2Screen;
