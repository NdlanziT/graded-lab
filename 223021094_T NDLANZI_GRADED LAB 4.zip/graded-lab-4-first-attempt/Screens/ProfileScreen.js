import React, { useContext } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { useFormContext } from '../contexts/FormContext';
import { useThemeContext } from '../contexts/ThemeContext';

const ProfileScreen = () => {
  const { userData } = useFormContext();
  const { theme, setTheme } = useThemeContext();

  const changeTheme = (newTextColor, newBgColor) => {
    setTheme({
      textColor: newTextColor,
      backgroundColor: newBgColor,
    });
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}>
      <View style={styles.card}>
        <Text style={[styles.text, { color: theme.textColor }]}>Name: {userData.name}</Text>
        <Text style={[styles.text, { color: theme.textColor }]}>Email: {userData.email}</Text>
      </View>
      <View style={styles.card}>
        <Text style={[styles.text, { color: theme.textColor }]}>Address: {userData.address}</Text>
        <Text style={[styles.text, { color: theme.textColor }]}>City: {userData.city}</Text>
        <Text style={[styles.text, { color: theme.textColor }]}>State: {userData.state}</Text>
      </View>
      <View style={styles.card}>
        <Button 
          title="Change to Dark Theme" 
          onPress={() => changeTheme('#ffffff', '#000000')} 
        />
        <Button 
          title="Change to Light Theme" 
          onPress={() => changeTheme('#000000', '#ffffff')} 
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  card: {
    padding: 15,
    marginBottom: 20,
    backgroundColor: '#f8f8f8',
    borderRadius: 10,
    elevation: 3,
  },
  text: {
    fontSize: 18,
  },
});

export default ProfileScreen;
