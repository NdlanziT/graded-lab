import React, { useContext } from 'react';
import { View, Text, Button, FlatList, StyleSheet, Image, Alert } from 'react-native';
import { CartContext } from '../contexts/CartContext'; 

const CartScreen = ({ navigation }) => {
  const { cart, updateItemQuantity, removeItemFromCart, getTotalPrice, clearCart } = useContext(CartContext);

  const handleUpdateQuantity = (id, quantity) => {
    updateItemQuantity(id, quantity);
  };

  const handleCheckout = () => {
    Alert.alert(
      "Confirm Checkout",
      "Are you sure you want to proceed to checkout?",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        {
          text: "OK",
          onPress: () => {
            clearCart();
            navigation.navigate('Checkout'); 
          }
        }
      ]
    );
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={cart}
        renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <View style={styles.detailsContainer}>
              <Text style={styles.name}>{item.name}</Text>
              <Text>{item.description}</Text>
              <Text>Price: R{item.price}</Text>
              <View style={styles.quantityContainer}>
                <Button
                  title="-"
                  onPress={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                />
                <Text style={styles.quantity}>{item.quantity}</Text>
                <Button
                  title="+"
                  onPress={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                />
              </View>
              <Button
                title="Remove"
                onPress={() => removeItemFromCart(item.id)}
              />
            </View>
          </View>
        )}
        keyExtractor={(item) => item.id.toString()}
      />
      <View style={styles.totalContainer}>
        <Text style={styles.totalText}>Total Price: R{getTotalPrice().toFixed(2)}</Text>
        <Button title="Proceed to Checkout" onPress={handleCheckout} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  itemContainer: {
    flexDirection: 'row',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    borderRadius: 5,
  },
  image: {
    width: 80,
    height: 80,
    marginRight: 10,
  },
  detailsContainer: {
    flex: 1,
    justifyContent: 'space-between',
  },
  name: {
    fontWeight: 'bold',
    fontSize: 18,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  quantity: {
    marginHorizontal: 10,
    fontSize: 16,
  },
  totalContainer: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#f8f8f8',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    alignItems: 'center',
  },
  totalText: {
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 10,
  },
});

export default CartScreen;
