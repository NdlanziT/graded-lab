import React, { useContext, useState } from 'react';
import { View, TextInput, Button, Text } from 'react-native';
import { FormContext } from '../contexts/FormContext';

const Form3Screen = ({ navigation }) => {
  const { userData, setUserData } = useContext(FormContext);
  const [cardNumber, setCardNumber] = useState(userData.cardNumber);
  const [expiryDate, setExpiryDate] = useState(userData.expiryDate);
  const [cvv, setCvv] = useState(userData.cvv);

  const handleSubmit = () => {
    if (cardNumber.length === 16 && expiryDate && cvv.length === 3) {
      setUserData({ ...userData, cardNumber, expiryDate, cvv });
      alert('Form Submitted!');
      navigation.navigate('Profile');
    } else {
      alert('Please enter valid payment details');
    }
  };

  return (
    <View>
      <Text>Payment Details</Text>
      <TextInput
        placeholder="Card Number"
        value={cardNumber}
        keyboardType="numeric"
        onChangeText={setCardNumber}
        maxLength={16}
      />
      <TextInput
        placeholder="Expiry Date (MM/YY)"
        value={expiryDate}
        onChangeText={setExpiryDate}
      />
      <TextInput
        placeholder="CVV"
        value={cvv}
        keyboardType="numeric"
        onChangeText={setCvv}
        maxLength={3}
      />
      <Button title="Submit" onPress={handleSubmit} />
    </View>
  );
};

export default Form3Screen;
