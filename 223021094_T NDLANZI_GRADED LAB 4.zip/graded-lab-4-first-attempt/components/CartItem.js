import React from 'react';
import { View, Text, Image, Button } from 'react-native';

const CartItem = ({ item, onUpdateQuantity, onRemoveFromCart }) => {
  return (
    <View style={{ margin: 10 }}>
      <Image source={{ uri: item.image }} style={{ width: 100, height: 100 }} />
      <Text>{item.name}</Text>
      <Text>Quantity: {item.quantity}</Text>
      <Button title="Increase" onPress={() => onUpdateQuantity(item.id, item.quantity + 1)} />
      <Button title="Decrease" onPress={() => onUpdateQuantity(item.id, item.quantity - 1)} />
      <Button title="Remove" onPress={() => onRemoveFromCart(item.id)} />
    </View>
  );
};

export default CartItem;
