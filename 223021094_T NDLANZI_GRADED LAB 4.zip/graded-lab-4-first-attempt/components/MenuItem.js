import React from 'react';
import { View, Text, Image, Button } from 'react-native';

const MenuItem = ({ item, onAddToCart }) => {
  return (
    <View style={{ margin: 10 }}>
      <Image source={{ uri: item.image }} style={{ width: 100, height: 100 }} />
      <Text>{item.name}</Text>
      <Text>{item.description}</Text>
      <Text>{item.price}</Text>
      <Button title="Add to Cart" onPress={() => onAddToCart(item)} />
    </View>
  );
};

export default MenuItem;
