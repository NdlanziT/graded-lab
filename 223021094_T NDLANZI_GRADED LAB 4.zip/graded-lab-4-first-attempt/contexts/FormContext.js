import React, { createContext, useState } from 'react';
import { useFormContext } from '../contexts/FormContext';

export const FormContext = createContext();

export const FormProvider = ({ children }) => {
  const [userData, setUserData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zip: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
  });

  return (
    <FormContext.Provider value={{ userData, setUserData }}>
      {children}
    </FormContext.Provider>
  );
};

