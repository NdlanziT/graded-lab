import React, { useContext } from 'react';
import { CartContext } from './CartContext';

const CheckoutButton = () => {
  const { checkout } = useContext(CartContext);

  return (
    <button onClick={checkout}>
      Proceed to Checkout
    </button>
  );
};

export default CheckoutButton;
