import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import MenuScreen from './Screens/MenuScreen';
import CartScreen from './Screens/CartScreen';
import ProfileScreen from './Screens/ProfileScreen';
import Form1Screen from './Screens/Form1Screen';
import Form2Screen from './Screens/Form2Screen';
import Form3Screen from './Screens/Form3Screen'; 
import { CartProvider } from './contexts/CartContext';
import { FormProvider } from './contexts/FormContext';
import { ThemeProvider } from './contexts/ThemeContext';

const Stack = createStackNavigator();

function App() {
  return (
    <ThemeProvider>
      <FormProvider>
        <CartProvider>
          <NavigationContainer>
            <Stack.Navigator initialRouteName="Menu">
              <Stack.Screen 
                name="Menu" 
                component={MenuScreen} 
                options={{ title: 'Menu' }}
              />
              <Stack.Screen 
                name="Cart" 
                component={CartScreen} 
                options={{ title: 'Cart' }}
              />
              <Stack.Screen 
                name="Profile" 
                component={ProfileScreen} 
                options={{ title: 'Profile' }}
              />
              <Stack.Screen 
                name="Form1" 
                component={Form1Screen} 
                options={{ title: 'User Details' }}
              />
              <Stack.Screen 
                name="Form2" 
                component={Form2Screen} 
                options={{ title: 'Address Details' }}
              />
              <Stack.Screen 
                name="Form3" 
                component={Form3Screen} 
                options={{ title: 'Other Details' }} 
              />
            </Stack.Navigator>
          </NavigationContainer>
        </CartProvider>
      </FormProvider>
    </ThemeProvider>
  );
}

export default App;
